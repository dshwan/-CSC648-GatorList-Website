<template>
    <div class="jumbotron jumbotron-fluid my-0 py-0">
        <div class="container">
            <p class="lead text-center jumbotron-content-bigger m-0 p-0">Software Engineering class SFSU</p>
            <p class="lead text-center jumbotron-content-bigger m-0 p-0">Spring 2019</p>
            <p class="lead text-center jumbotron-content-bigger m-0 p-0">Section-01</p>
            <p class="lead text-center jumbotron-content-bigger m-0 p-0">Team-04</p>
            <hr class="mt-1 mb-3">
        </div>
    </div>
</template>

<style scoped>
    /* remove background color from jumbotron */
    .jumbotron {
        background: transparent;
    }
    p.lead.text-center.jumbotron-content-bigger.mb-1{
        font-size: 1.25rem !important;
    }
</style>


