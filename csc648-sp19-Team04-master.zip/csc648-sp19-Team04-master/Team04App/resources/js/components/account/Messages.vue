<template>
    <div> display user messages here </div>
</template>
